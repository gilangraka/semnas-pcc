 <?php $__env->startSection('title', 'Seminar Nasional 2025'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginala170c35e1e4f6eaccfbe9693a79b465f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala170c35e1e4f6eaccfbe9693a79b465f = $attributes; } ?>
<?php $component = App\View\Components\Sections\HeroSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.hero-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sections\HeroSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala170c35e1e4f6eaccfbe9693a79b465f)): ?>
<?php $attributes = $__attributesOriginala170c35e1e4f6eaccfbe9693a79b465f; ?>
<?php unset($__attributesOriginala170c35e1e4f6eaccfbe9693a79b465f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala170c35e1e4f6eaccfbe9693a79b465f)): ?>
<?php $component = $__componentOriginala170c35e1e4f6eaccfbe9693a79b465f; ?>
<?php unset($__componentOriginala170c35e1e4f6eaccfbe9693a79b465f); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal0051b756539d02591d76104fe2595902 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0051b756539d02591d76104fe2595902 = $attributes; } ?>
<?php $component = App\View\Components\Sections\AboutSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.about-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sections\AboutSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0051b756539d02591d76104fe2595902)): ?>
<?php $attributes = $__attributesOriginal0051b756539d02591d76104fe2595902; ?>
<?php unset($__attributesOriginal0051b756539d02591d76104fe2595902); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0051b756539d02591d76104fe2595902)): ?>
<?php $component = $__componentOriginal0051b756539d02591d76104fe2595902; ?>
<?php unset($__componentOriginal0051b756539d02591d76104fe2595902); ?>
<?php endif; ?>
<section class="p-4" id="fillers">
    <div class="flex justify-between items-center"></div>
</section>
<?php if (isset($component)) { $__componentOriginal9cc18dc2f79b9f39b2764cc2b1b63de4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9cc18dc2f79b9f39b2764cc2b1b63de4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sections.benefit-section','data' => ['benefitItems' => $benefitItems]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.benefit-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['benefitItems' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($benefitItems)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9cc18dc2f79b9f39b2764cc2b1b63de4)): ?>
<?php $attributes = $__attributesOriginal9cc18dc2f79b9f39b2764cc2b1b63de4; ?>
<?php unset($__attributesOriginal9cc18dc2f79b9f39b2764cc2b1b63de4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9cc18dc2f79b9f39b2764cc2b1b63de4)): ?>
<?php $component = $__componentOriginal9cc18dc2f79b9f39b2764cc2b1b63de4; ?>
<?php unset($__componentOriginal9cc18dc2f79b9f39b2764cc2b1b63de4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginaldc97c880763a079d35ada835328c1a75 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc97c880763a079d35ada835328c1a75 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sections.faq-section','data' => ['faqItems' => $faqItems]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.faq-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['faqItems' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($faqItems)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc97c880763a079d35ada835328c1a75)): ?>
<?php $attributes = $__attributesOriginaldc97c880763a079d35ada835328c1a75; ?>
<?php unset($__attributesOriginaldc97c880763a079d35ada835328c1a75); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc97c880763a079d35ada835328c1a75)): ?>
<?php $component = $__componentOriginaldc97c880763a079d35ada835328c1a75; ?>
<?php unset($__componentOriginaldc97c880763a079d35ada835328c1a75); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/pages/home.blade.php ENDPATH**/ ?>