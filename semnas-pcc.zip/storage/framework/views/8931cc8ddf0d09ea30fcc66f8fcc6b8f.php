<button
    class="w-full mt-4 mb-12 p-2 px-6 bg-gradient-to-r from-sem-dark-blue to-sem-light-blue text-white rounded-md"
>
    <?php echo e($slot); ?>

</button><?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/components/partials/button-primary.blade.php ENDPATH**/ ?>