<section
    class="h-screen my-auto grid place-content-center p-4"
    data-aos="fade-down"
    data-aos-duration="1000"
>
    <div class="flex flex-col-reverse md:flex-row gap-4 items-center">
        <div
            class="bg-clip-text text-transparent bg-gradient-to-r from-sem-dark-blue to-sem-light-blue drop-shadow-lg"
        >
            <h2 class="text-6xl md:text-8xl font-medium">Seminar Nasional</h2>
            <div class="flex flex-col md:flex-row md:items-center">
                <h2 class="text-6xl font-medium">2025</h2>
                <p class="">
                    Elevate Your LinkedIn Presence <br />with Powerful Personal
                    Branding Strategies
                </p>
            </div>
            <div class="flex gap-4 mt-4">
                <?php if(auth()->guard()->check()): ?>
                <?php if (isset($component)) { $__componentOriginalc359f256a8c6af01b9c33fee811a102d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc359f256a8c6af01b9c33fee811a102d = $attributes; } ?>
<?php $component = App\View\Components\Partials\ButtonLink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Partials\ButtonLink::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('dashboard.index')).'','class' => 'bg-gradient-to-r from-sem-dark-blue to-sem-light-blue text-white']); ?>
                    Daftar Sekarang
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $attributes = $__attributesOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $component = $__componentOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__componentOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
                <?php endif; ?> <?php if(auth()->guard()->guest()): ?>
                <?php if (isset($component)) { $__componentOriginalc359f256a8c6af01b9c33fee811a102d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc359f256a8c6af01b9c33fee811a102d = $attributes; } ?>
<?php $component = App\View\Components\Partials\ButtonLink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Partials\ButtonLink::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('login')).'','class' => 'bg-gradient-to-r from-sem-dark-blue to-sem-light-blue text-white']); ?>
                    Daftar Sekarang
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $attributes = $__attributesOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $component = $__componentOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__componentOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="drop-shadow-lg">
            <img
                src="<?php echo e(asset('img/logo-semnas.png')); ?>"
                alt="Logo Semnas"
                class="w-[250px] md:w-full"
            />
        </div>
    </div>
</section><?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/components/sections/hero-section.blade.php ENDPATH**/ ?>