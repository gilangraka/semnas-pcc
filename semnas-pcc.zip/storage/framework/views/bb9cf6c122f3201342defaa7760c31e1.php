<section id="benefit" class="relative px-4">
    <div class="text-center my-4 text-slate-800" data-aos="fade-down" data-aos-duration="1000">
        <h2
            class="text-4xl md:text-5xl font-bold bg-gradient-to-r from-co-dark-blue to-co-pink text-transparent bg-clip-text drop-shadow-2xl transform hover:scale-105 transition-transform duration-300 ease-in-out">
            Benefit
        </h2>
        <p class="font-semibold text-lg text-co-dark-blue mt-3 mb-12">
            Benefit apa saja sih yang akan kalian dapatkan?
        </p>
    </div>
    <ul class="flex flex-wrap justify-center gap-12 px-12 py-6 md:px-4" data-aos="fade-up" data-aos-duration="1000">
        <?php $__currentLoopData = $benefitItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="relative w-full sm:w-1/2 md:w-1/4">
                <div
                    class="bg-white rounded-lg shadow-lg p-6 flex flex-col items-center transition-all duration-300 ease-in-out transform hover:scale-105">
                    <img src="<?php echo e(asset('img/' . $item->imgUrl)); ?>" alt="<?php echo e($item->title); ?>" class="max-w-[150px]" />
                    <p class="text-co-dark-blue font-semibold text-xl text-center"><?php echo e($item->title); ?></p>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</section>
<?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/components/sections/benefit-section.blade.php ENDPATH**/ ?>