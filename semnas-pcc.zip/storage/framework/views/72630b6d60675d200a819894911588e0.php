<a <?php echo e($attributes->merge([ 
    'class' => 'px-5 py-2 rounded-full hover:scale-[0.96] duration-300',
    'href' => '' 
    ])); ?> >
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/components/partials/button-link.blade.php ENDPATH**/ ?>