<header class="fixed bg-white drop-shadow-sm left-0 right-0 z-20 p-2">
    <nav class="flex justify-between items-center w-[92%] mx-auto">
        <div>
            <img
                class="w-16 cursor-pointer"
                src="<?php echo e(asset('img/logo-semnas.png')); ?>"
                alt="Logo Techomfest"
            />
        </div>
        <div
            class="nav-links duration-500 md:static absolute bg-white md:min-h-fit min-h-[60vh] left-0 -top-[800px] md:w-auto w-full flex items-center px-5"
        >
            <ul
                class="flex md:flex-row flex-col md:items-center md:gap-[4vw] gap-8"
            >
                <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginale4ab10e54832a606d08a208396899ba2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4ab10e54832a606d08a208396899ba2 = $attributes; } ?>
<?php $component = App\View\Components\NavItem::resolve(['navItem' => $navItem] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\NavItem::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4ab10e54832a606d08a208396899ba2)): ?>
<?php $attributes = $__attributesOriginale4ab10e54832a606d08a208396899ba2; ?>
<?php unset($__attributesOriginale4ab10e54832a606d08a208396899ba2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4ab10e54832a606d08a208396899ba2)): ?>
<?php $component = $__componentOriginale4ab10e54832a606d08a208396899ba2; ?>
<?php unset($__componentOriginale4ab10e54832a606d08a208396899ba2); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="flex items-center gap-6">
            <?php if(auth()->guard()->check()): ?>
            <?php if (isset($component)) { $__componentOriginalc359f256a8c6af01b9c33fee811a102d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc359f256a8c6af01b9c33fee811a102d = $attributes; } ?>
<?php $component = App\View\Components\Partials\ButtonLink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Partials\ButtonLink::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('dashboard.index')).'','class' => 'bg-gradient-to-r from-co-dark-blue to-co-pink text-white']); ?>
                Dashboard
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $attributes = $__attributesOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $component = $__componentOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__componentOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
            <?php endif; ?> 
            <?php if(auth()->guard()->guest()): ?>
            <?php if (isset($component)) { $__componentOriginalc359f256a8c6af01b9c33fee811a102d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc359f256a8c6af01b9c33fee811a102d = $attributes; } ?>
<?php $component = App\View\Components\Partials\ButtonLink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Partials\ButtonLink::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('login')).'','class' => 'bg-gradient-to-r from-sem-dark-blue to-sem-light-blue text-white']); ?>
                Masuk
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $attributes = $__attributesOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $component = $__componentOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__componentOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
            <?php endif; ?>
            <ion-icon
                onclick="onToggleMenu(this)"
                name="menu"
                class="text-3xl cursor-pointer md:hidden"
            ></ion-icon>
        </div>
    </nav>
</header>

<?php $__env->startPush('scripts'); ?>
<script>
    const navLinks = document.querySelector(".nav-links");
    function onToggleMenu(e) {
        e.name = e.name === "menu" ? "close" : "menu";

        if (navLinks.classList.contains("-top-[800px]")) {
            navLinks.classList.remove("-top-[800px]");
            navLinks.classList.add("top-0");
        } else {
            navLinks.classList.remove("top-0");
            navLinks.classList.add("-top-[800px]");
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/components/header.blade.php ENDPATH**/ ?>