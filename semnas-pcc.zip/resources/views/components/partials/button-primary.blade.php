<button
    class="w-full mt-4 mb-12 p-2 px-6 bg-gradient-to-r from-sem-dark-blue to-sem-light-blue text-white rounded-md"
>
    {{ $slot }}
</button>