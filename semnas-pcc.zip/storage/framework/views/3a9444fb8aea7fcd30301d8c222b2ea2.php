<div class="row mt-3">
    <p class="col-lg-3 col-md-4 label "><b>Nama Lengkap</b></p>
    <p class="col-lg-9 col-md-8"><?php echo e($data->name); ?></p>
</div>

<div class="row mt-3">
    <p class="col-lg-3 col-md-4 label "><b>Email</b></p>
    <p class="col-lg-9 col-md-8"><?php echo e($data->email); ?></p>
</div>

<div class="row mt-3">
    <p class="col-lg-3 col-md-4 label "><b>Nomor WA</b></p>
    <p class="col-lg-9 col-md-8"><?php echo e($data->ref_peserta->nomor_hp); ?></p>
</div>

<div class="row mt-3">
    <p class="col-lg-3 col-md-4 label "><b>Asal Instansi</b></p>
    <p class="col-lg-9 col-md-8"><?php echo e($data->ref_peserta->instansi); ?></p>
</div>

<div class="row mt-3">
    <p class="col-lg-3 col-md-4 label "><b>Profesi</b></p>
    <p class="col-lg-9 col-md-8"><?php echo e($data->ref_peserta->profesi); ?></p>
</div>

<div class="row mt-3">
    <p class="col-lg-3 col-md-4 label "><b>Login Sebagai</b></p>
    <p class="col-lg-9 col-md-8">
        <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($item); ?><?php if(!$loop->last): ?>
                ,
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </p>
</div>

<div class="row mt-3">
    <p class="col-lg-3 col-md-4 label "><b>Status Pembayaran</b></p>
    <p class="col-lg-9 col-md-8">
        <?php if(!$data->ref_peserta->ref_qrcode): ?>
            <span class="text-danger">Belum Dibayar</span>
        <?php else: ?>
            <span class="text-success">Sudah Dibayar</span>
        <?php endif; ?>
    </p>
</div>
<div class="row mt-3">
    <div class="col-lg-3 col-md-4 label ">
        <p><b>Bukti Pembayaran</b></p>
    </div>
    <div class="col-lg-9 col-md-8">
        <?php if(!$data->ref_peserta->ref_qrcode): ?>
            <form action="<?php echo e(route('pembayaran.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary d-flex gap-3 align-items-center">Bayar Sekarang</button>
            </form>
        <?php else: ?>
            <img src="<?php echo e(asset('storage/qr_code') . '/' . $data->ref_peserta->ref_qrcode->file_qrcode); ?>"
                width="150" />
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/pages/dashboard/overview.blade.php ENDPATH**/ ?>