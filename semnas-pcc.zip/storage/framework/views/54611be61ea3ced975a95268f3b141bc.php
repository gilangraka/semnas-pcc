<!DOCTYPE html>
<html lang='<?php echo e(str_replace('_', '-', app()->getLocale())); ?>'>

<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" href="<?php echo e(asset('img/tcfest2025.webp')); ?>" type="image/png">

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>

<body class="text-slate-800">

    <main class='grid items-center'>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/layouts/auth.blade.php ENDPATH**/ ?>