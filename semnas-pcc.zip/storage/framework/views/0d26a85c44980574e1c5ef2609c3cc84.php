<li>
    <a
        class="hover:text-co-dark-blue duration-300"
        href="<?php echo e($navItem->href); ?>"
        ><?php echo e($navItem->name); ?></a
    >
</li>
<?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/components/nav-item.blade.php ENDPATH**/ ?>