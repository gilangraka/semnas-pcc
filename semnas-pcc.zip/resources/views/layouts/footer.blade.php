{{-- Footer --}}
<footer class="app-footer text-center">
    <strong>
        Copyright &copy; 2024&nbsp;
        <a href="https://www.instagram.com/pccpolines/" class="text-decoration-none" target="_blank">Polytechnic
            Computer
            Club</a>.
    </strong>
    All rights reserved.
</footer>
{{-- End Footer --}}
