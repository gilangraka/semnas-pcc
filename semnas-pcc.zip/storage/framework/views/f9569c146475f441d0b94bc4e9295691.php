 
<?php $__env->startSection('title', 'Seminar Nasional 2025 Login Form'); ?>

<div class="mt-8 px-12">
    <?php if (isset($component)) { $__componentOriginalc359f256a8c6af01b9c33fee811a102d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc359f256a8c6af01b9c33fee811a102d = $attributes; } ?>
<?php $component = App\View\Components\Partials\ButtonLink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Partials\ButtonLink::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/','class' => 'w-[150px] flex items-center gap-2 bg-slate-100']); ?>
        <?php if (isset($component)) { $__componentOriginal470a58774146dfefeb6e33f47f6b3f86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal470a58774146dfefeb6e33f47f6b3f86 = $attributes; } ?>
<?php $component = App\View\Components\Partials\BackSvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.back-svg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Partials\BackSvg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal470a58774146dfefeb6e33f47f6b3f86)): ?>
<?php $attributes = $__attributesOriginal470a58774146dfefeb6e33f47f6b3f86; ?>
<?php unset($__attributesOriginal470a58774146dfefeb6e33f47f6b3f86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal470a58774146dfefeb6e33f47f6b3f86)): ?>
<?php $component = $__componentOriginal470a58774146dfefeb6e33f47f6b3f86; ?>
<?php unset($__componentOriginal470a58774146dfefeb6e33f47f6b3f86); ?>
<?php endif; ?>
        Kembali
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $attributes = $__attributesOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__attributesOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc359f256a8c6af01b9c33fee811a102d)): ?>
<?php $component = $__componentOriginalc359f256a8c6af01b9c33fee811a102d; ?>
<?php unset($__componentOriginalc359f256a8c6af01b9c33fee811a102d); ?>
<?php endif; ?>
</div>
<div class="px-4 md:px-12 mx-auto">
    <div class="grid md:grid-cols-2 md:gap-8">
        <div id="login-image">
            <img src="<?php echo e(asset('img/logo-semnas.png')); ?>" alt="Logo Seminar Nasional 2025" class="w-full" />
        </div>
        <div class="items-center my-auto p-8 rounded-md w-full" id="login-form">
            <h1 class="font-bold text-3xl">Masuk</h1>
            <p>Masuk menggunakan data Anda yang valid.</p>
            <form action="<?php echo e(route('login.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="my-4">
                    <?php if (isset($component)) { $__componentOriginalc74bef72caef5ea1cc01646206d12aab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc74bef72caef5ea1cc01646206d12aab = $attributes; } ?>
<?php $component = App\View\Components\Partials\FormInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Partials\FormInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','name' => 'email','placeholder' => 'Masukkan Email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc74bef72caef5ea1cc01646206d12aab)): ?>
<?php $attributes = $__attributesOriginalc74bef72caef5ea1cc01646206d12aab; ?>
<?php unset($__attributesOriginalc74bef72caef5ea1cc01646206d12aab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc74bef72caef5ea1cc01646206d12aab)): ?>
<?php $component = $__componentOriginalc74bef72caef5ea1cc01646206d12aab; ?>
<?php unset($__componentOriginalc74bef72caef5ea1cc01646206d12aab); ?>
<?php endif; ?>
                </div>
                <div class="my-4">
                    <?php if (isset($component)) { $__componentOriginalc74bef72caef5ea1cc01646206d12aab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc74bef72caef5ea1cc01646206d12aab = $attributes; } ?>
<?php $component = App\View\Components\Partials\FormInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Partials\FormInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Password','name' => 'password','placeholder' => 'Masukkan password','type' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc74bef72caef5ea1cc01646206d12aab)): ?>
<?php $attributes = $__attributesOriginalc74bef72caef5ea1cc01646206d12aab; ?>
<?php unset($__attributesOriginalc74bef72caef5ea1cc01646206d12aab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc74bef72caef5ea1cc01646206d12aab)): ?>
<?php $component = $__componentOriginalc74bef72caef5ea1cc01646206d12aab; ?>
<?php unset($__componentOriginalc74bef72caef5ea1cc01646206d12aab); ?>
<?php endif; ?>
                </div>

                <?php if (isset($component)) { $__componentOriginal9d3d4dbe3fef54f406ea68a6dc5de22c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d3d4dbe3fef54f406ea68a6dc5de22c = $attributes; } ?>
<?php $component = App\View\Components\Partials\ButtonPrimary::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('partials.button-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Partials\ButtonPrimary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    Login
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d3d4dbe3fef54f406ea68a6dc5de22c)): ?>
<?php $attributes = $__attributesOriginal9d3d4dbe3fef54f406ea68a6dc5de22c; ?>
<?php unset($__attributesOriginal9d3d4dbe3fef54f406ea68a6dc5de22c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d3d4dbe3fef54f406ea68a6dc5de22c)): ?>
<?php $component = $__componentOriginal9d3d4dbe3fef54f406ea68a6dc5de22c; ?>
<?php unset($__componentOriginal9d3d4dbe3fef54f406ea68a6dc5de22c); ?>
<?php endif; ?>

                <div class="flex flex-col sm:flex-row gap-3 justify-between items-center">
                    <div class="text-sm text-gray-800 underline">
                        <a href="/register">Belum punya akun?</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush("scripts"); ?>
<script>
const isMobile = window.matchMedia("(max-width: 768px)").matches;

const loginImg = document.getElementById("login-img");
const LoginForm = document.getElementById("login-form");

if (isMobile) {
  loginImg.setAttribute("data-aos", "fade-down"); 
  loginImg.setAttribute("data-aos-duration", "800"); 
  LoginForm.setAttribute("data-aos", "fade-up"); 
  LoginForm.setAttribute("data-aos-duration", "800"); 
} else {
  loginImg.setAttribute("data-aos", "fade-right");
  loginImg.setAttribute("data-aos-duration", "1000");
  LoginForm.setAttribute("data-aos", "fade-left");
  LoginForm.setAttribute("data-aos-duration", "1000");
}

AOS.init();

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/pages/auth/login.blade.php ENDPATH**/ ?>