<li>
    <a
        class="hover:text-co-dark-blue duration-300"
        href="{{ $navItem->href }}"
        >{{ $navItem->name }}</a
    >
</li>
