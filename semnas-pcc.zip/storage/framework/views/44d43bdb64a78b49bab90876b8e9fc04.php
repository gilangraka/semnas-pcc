<!DOCTYPE html>
<html lang='<?php echo e(str_replace('_', '-', app()->getLocale())); ?>'>

<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>Seminar Nasional</title>
    <link rel="icon" href="<?php echo e(asset('img/knowledge.webp')); ?>" type="image/png">

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>

<body class="text-slate-800 flex flex-col gap-y-32">

    <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class='container mx-auto flex flex-col gap-y-32'>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src='https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js'></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\Users\gilan\OneDrive\Desktop\semnas-pcc\resources\views/layouts/app.blade.php ENDPATH**/ ?>